from django.contrib import admin
from .models import Meetups, Location, Participant

# Register your models here.
class Meetup_Config(admin.ModelAdmin):
    list_display = ('title', 'date', 'location') #display
    list_filter = ['date','location'] #filter
    prepopulated_field = { 'slug' : ('title')}
admin.site.register(Meetups, Meetup_Config)
admin.site.register(Location)
admin.site.register(Participant)