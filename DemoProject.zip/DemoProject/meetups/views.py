from django.shortcuts import redirect, render
from django.http import HttpResponse
from .models import Meetups, Participant
from .forms import Registration_Form

# Create your views here.

def index(request):
    meetups = Meetups.objects.all()
    return render(request,'meetups/index.html', { 'meetups' : meetups })

def meetup_details(request,meetId):
    try:
        meetup_details = Meetups.objects.get(slug=meetId)
        if request.method == 'GET':
            register_form = Registration_Form()
            
        else:
            register_form = Registration_Form(request.POST)
            if register_form.is_valid():
                participant_email = register_form.cleaned_data['email']
                participant, was_created = Participant.objects.get_or_create(email=participant_email)
                meetup_details.participant.add(participant)
                return redirect('registration-success',meetId = meetId)
        return render(
            request, 'meetups/meetup-details.html',
            {
                'meetup_details' : meetup_details, 
                'isMeetup':True,
                'form' : register_form

            }
        )

    except Exception as exc:
        print(exc)
        return render(request,'meetups/meetup-details.html', {'isMeetup' :  False})

def registration_success(request, meetId):
    meetup_details = Meetups.objects.get(slug=meetId)
    return render(request, 'meetups/registration-confirmation.html', {'meetup_details':meetup_details} )