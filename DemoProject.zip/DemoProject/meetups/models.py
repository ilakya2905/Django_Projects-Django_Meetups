from django.db import models
from django.db.models.fields import CharField, TextField

# Create your models here.
class Location(models.Model):
    address = TextField()
    city = CharField(max_length=200)
    def __str__(self):
        return f'{self.address} - {self.city}'
class Participant(models.Model):
    email = models.EmailField(unique=True)
    def __str__(self):
        return f'{self.email}'

class Meetups(models.Model):
    title = models.CharField(max_length=200)
    organizer_email = models.EmailField()
    date= models.DateField()
    slug = models.SlugField(unique=True)
    description = models.TextField()
    image = models.ImageField(upload_to='images')
    location = models.ForeignKey(Location,on_delete=models.SET_NULL, null=True)
    participant = models.ManyToManyField(Participant,blank=True)



    def __str__(self):
        return f'{self.title} - {self.date}'
