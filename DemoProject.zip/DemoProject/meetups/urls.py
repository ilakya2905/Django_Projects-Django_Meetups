from django.urls import path
from . import views
urlpatterns = [
    path('', views.index, name="all-meetups"),
    path('<slug:meetId>', views.meetup_details, name="meetup-details"),
    path('<slug:meetId>/success/',views.registration_success, name="registration-success")
]